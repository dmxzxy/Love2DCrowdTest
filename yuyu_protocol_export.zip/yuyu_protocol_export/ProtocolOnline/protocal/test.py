s = 'asdasdasdasdasd'
print s[1:]